"""Test adapters - simplified without type annotations to avoid jaxtyping issues."""

import os
import torch
import numpy as np


# ============================================================================
# Basic Layers
# ============================================================================

def run_linear(d_in, d_out, weights, in_features):
    """Run Linear layer with given weights."""
    from student.layers import Linear
    
    linear = Linear(d_in, d_out)
    linear.weight.data = weights
    return linear(in_features)


def run_embedding(vocab_size, d_model, weights, token_ids):
    """Run Embedding layer with given weights."""
    from student.layers import Embedding
    
    embedding = Embedding(vocab_size, d_model)
    embedding.weight.data = weights
    return embedding(token_ids)


def run_rmsnorm(d_model, eps, weights, in_features):
    """Run RMSNorm with given weights."""
    from student.layers import RMSNorm
    
    rmsnorm = RMSNorm(d_model, eps=eps)
    rmsnorm.weight.data = weights
    return rmsnorm(in_features)


# ============================================================================
# Activation Functions
# ============================================================================

def run_silu(in_features):
    """Apply SiLU activation."""
    from student.training import silu
    return silu(in_features)


def run_softmax(in_features, dim):
    """Apply softmax."""
    from student.training import softmax
    return softmax(in_features, dim)


# ============================================================================
# Feedforward
# ============================================================================

def run_swiglu(d_model, d_ff, w1_weight, w2_weight, w3_weight, in_features):
    """Run SwiGLU with given weights."""
    from student.feedforward import SwiGLU
    
    swiglu = SwiGLU(d_model, d_ff)
    swiglu.w1.weight.data = w1_weight
    swiglu.w2.weight.data = w2_weight
    swiglu.w3.weight.data = w3_weight
    return swiglu(in_features)


# ============================================================================
# Attention Components
# ============================================================================

def run_rope(d_k, theta, max_seq_len, in_query_or_key, token_positions):
    """Run RoPE on input."""
    from student.attention import RotaryPositionalEmbedding
    
    rope = RotaryPositionalEmbedding(d_k, theta, max_seq_len)
    return rope(in_query_or_key, token_positions)


def run_scaled_dot_product_attention(Q, K, V, mask=None):
    """Run scaled dot-product attention."""
    from student.attention import scaled_dot_product_attention
    
    return scaled_dot_product_attention(Q, K, V, mask)


def run_multihead_self_attention(d_model, num_heads, q_proj_weight, 
                                  k_proj_weight, v_proj_weight, 
                                  o_proj_weight, in_features):
    """Run multi-head attention WITHOUT RoPE."""
    from student.attention import MultiHeadAttention
    
    mha = MultiHeadAttention(d_model, num_heads, use_rope=False)
    mha.q_proj.weight.data = q_proj_weight
    mha.k_proj.weight.data = k_proj_weight
    mha.v_proj.weight.data = v_proj_weight
    mha.output_proj.weight.data = o_proj_weight
    
    return mha(in_features)


def run_multihead_self_attention_with_rope(d_model, num_heads, max_seq_len, 
                                            theta, q_proj_weight, k_proj_weight, 
                                            v_proj_weight, o_proj_weight, 
                                            in_features, token_positions=None):
    """Run multi-head attention WITH RoPE."""
    from student.attention import MultiHeadAttention
    
    mha = MultiHeadAttention(
        d_model, 
        num_heads, 
        use_rope=True, 
        max_seq_len=max_seq_len,
        theta=theta
    )
    mha.q_proj.weight.data = q_proj_weight
    mha.k_proj.weight.data = k_proj_weight
    mha.v_proj.weight.data = v_proj_weight
    mha.output_proj.weight.data = o_proj_weight
    
    return mha(in_features, token_positions)


# ============================================================================
# Transformer Components
# ============================================================================

def run_transformer_block(d_model, num_heads, d_ff, max_seq_len, 
                          theta, weights, in_features):
    """Run Transformer block with given weights."""
    from student.model import TransformerBlock
    
    block = TransformerBlock(d_model, num_heads, d_ff, max_seq_len, theta)
    block.load_state_dict(weights)
    
    return block(in_features)


def run_transformer_lm(vocab_size, context_length, d_model, num_layers, 
                       num_heads, d_ff, rope_theta, weights, in_indices):
    """Run Transformer LM with given weights."""
    from student.model import TransformerLM
    
    model = TransformerLM(
        vocab_size,
        context_length,
        d_model,
        num_layers,
        num_heads,
        d_ff,
        rope_theta
    )
    model.load_state_dict(weights)
    
    return model(in_indices)


# ============================================================================
# Training Components
# ============================================================================

def run_cross_entropy(inputs, targets):
    """Compute cross-entropy loss."""
    from student.training import cross_entropy
    
    # Handle both 2D and 3D inputs
    if inputs.ndim == 2:
        inputs = inputs.unsqueeze(1)
        targets = targets.unsqueeze(1)
    
    return cross_entropy(inputs, targets)


def run_gradient_clipping(parameters, max_l2_norm):
    """Clip gradients."""
    from student.training import clip_gradients
    
    clip_gradients(parameters, max_l2_norm)


def get_adamw_cls():
    """Return AdamW class."""
    from student.training import AdamW
    
    return AdamW


def run_get_lr_cosine_schedule(it, max_learning_rate, min_learning_rate, 
                                warmup_iters, cosine_cycle_iters):
    """Get learning rate for given iteration."""
    from student.training import get_lr_cosine_schedule
    
    return get_lr_cosine_schedule(
        it, 
        max_learning_rate, 
        min_learning_rate, 
        warmup_iters, 
        cosine_cycle_iters
    )


# ============================================================================
# Data Loading & Checkpointing
# ============================================================================

def run_get_batch(dataset, batch_size, context_length, device):
    """Sample batch from dataset."""
    from student.data import get_batch
    
    return get_batch(dataset, batch_size, context_length, device)


def run_save_checkpoint(model, optimizer, iteration, out):
    """Save checkpoint."""
    from student.training import save_checkpoint
    
    save_checkpoint(model, optimizer, iteration, out)


def run_load_checkpoint(src, model, optimizer):
    """Load checkpoint."""
    from student.training import load_checkpoint
    
    return load_checkpoint(src, model, optimizer)


# ============================================================================
# BPE Tokenizer
# ============================================================================

def get_tokenizer(vocab, merges, special_tokens=None):
    """Create tokenizer from vocab and merges."""
    from student.tokenizer import Tokenizer
    
    return Tokenizer(vocab, merges, special_tokens)


def run_train_bpe(input_path, vocab_size, special_tokens, **kwargs):
    """Train BPE tokenizer."""
    from student.tokenizer import train_bpe
    
    return train_bpe(input_path, vocab_size, special_tokens)