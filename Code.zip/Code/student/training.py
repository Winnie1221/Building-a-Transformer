"""Training utilities for transformer language model."""

import torch
import torch.nn as nn
from typing import Iterable, Union
from pathlib import Path
import math


def silu(x: torch.Tensor) -> torch.Tensor:
    """SiLU (Swish) activation: x * sigmoid(x)."""
    return x * torch.sigmoid(x)


def softmax(x: torch.Tensor, dim: int) -> torch.Tensor:
    """Numerically stable softmax."""
    x_max = x.max(dim=dim, keepdim=True).values
    x_stable = x - x_max
    exp_x = torch.exp(x_stable)
    return exp_x / exp_x.sum(dim=dim, keepdim=True)


def cross_entropy(logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
    """
    Cross-entropy loss with numerical stability.
    
    Args:
        logits: Predicted logits (..., vocab_size)
        targets: Target token IDs (...,)
    
    Returns:
        Scalar loss (averaged over all elements)
    """
    # Flatten batch dimensions
    # logits: (batch, seq_len, vocab_size) -> (batch * seq_len, vocab_size)
    # targets: (batch, seq_len) -> (batch * seq_len,)
    logits_flat = logits.view(-1, logits.size(-1))
    targets_flat = targets.view(-1)
    
    # Subtract max for numerical stability
    x_max = logits_flat.max(dim=-1, keepdim=True).values
    x_stable = logits_flat - x_max
    
    # Compute log-sum-exp
    exp_x = torch.exp(x_stable)
    sum_exp = torch.sum(exp_x, dim=-1, keepdim=True)
    log_sum_exp = torch.log(sum_exp)
    
    # Compute log probabilities
    log_probs = x_stable - log_sum_exp
    
    # Gather log probabilities for target classes
    # Use advanced indexing: log_probs[i, targets_flat[i]] for all i
    target_log_probs = log_probs[torch.arange(len(targets_flat)), targets_flat]
    
    # Return mean negative log likelihood
    return -target_log_probs.mean()


def clip_gradients(parameters: Iterable[nn.Parameter], max_norm: float, eps: float = 1e-6) -> None:
    """
    Clip gradients by global L2 norm.
    
    Args:
        parameters: Iterable of parameters
        max_norm: Maximum gradient norm
        eps: Small value for numerical stability (default: 1e-6)
    """
    params_with_grad = [p for p in parameters if p.grad is not None]
    
    if len(params_with_grad) == 0:
        return
    
    # Compute global norm
    total_norm = 0.0
    for p in params_with_grad:
        param_norm = p.grad.data.norm(2)
        total_norm += param_norm.item() ** 2
    total_norm = math.sqrt(total_norm)
    
    # Clip if needed
    clip_coef = max_norm / (total_norm + eps)
    if clip_coef < 1:
        for p in params_with_grad:
            p.grad.data.mul_(clip_coef)


class AdamW(torch.optim.Optimizer):
    """
    AdamW optimizer with decoupled weight decay.
    
    Reference: Loshchilov & Hutter (2019)
    """
    
    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8, weight_decay=0.01):
        """
        Initialize AdamW optimizer.
        
        Args:
            params: Iterable of parameters to optimize
            lr: Learning rate
            betas: (beta1, beta2) for moment estimates
            eps: Small constant for numerical stability
            weight_decay: Weight decay coefficient
        """
        if lr < 0.0:
            raise ValueError(f"Invalid learning rate: {lr}")
        if eps < 0.0:
            raise ValueError(f"Invalid epsilon: {eps}")
        if not 0.0 <= betas[0] < 1.0:
            raise ValueError(f"Invalid beta1: {betas[0]}")
        if not 0.0 <= betas[1] < 1.0:
            raise ValueError(f"Invalid beta2: {betas[1]}")
        if weight_decay < 0.0:
            raise ValueError(f"Invalid weight_decay: {weight_decay}")
        
        defaults = dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay)
        super().__init__(params, defaults)
    
    def step(self, closure=None):
        """
        Perform a single optimization step.
        
        Args:
            closure: Optional closure to reevaluate the model
        
        Returns:
            Optional loss from closure
        """
        loss = None
        if closure is not None:
            loss = closure()
        
        for group in self.param_groups:
            lr = group['lr']
            beta1, beta2 = group['betas']
            eps = group['eps']
            weight_decay = group['weight_decay']
            
            for p in group['params']:
                if p.grad is None:
                    continue
                
                grad = p.grad.data
                state = self.state[p]
                
                # State initialization
                if len(state) == 0:
                    state['step'] = 0
                    state['exp_avg'] = torch.zeros_like(p.data)
                    state['exp_avg_sq'] = torch.zeros_like(p.data)
                
                exp_avg, exp_avg_sq = state['exp_avg'], state['exp_avg_sq']
                state['step'] += 1
                t = state['step']
                
                # Update biased first moment estimate
                exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1)
                
                # Update biased second raw moment estimate
                exp_avg_sq.mul_(beta2).addcmul_(grad, grad, value=1 - beta2)
                
                # Compute bias-corrected learning rate
                bias_correction1 = 1 - beta1 ** t
                bias_correction2 = 1 - beta2 ** t
                step_size = lr * math.sqrt(bias_correction2) / bias_correction1
                
                # Update parameters: p = p - step_size * m / (sqrt(v) + eps)
                p.data.addcdiv_(exp_avg, exp_avg_sq.sqrt().add_(eps), value=-step_size)
                
                # Decoupled weight decay: p = p - lr * lambda * p
                p.data.mul_(1 - lr * weight_decay)
        
        return loss


def get_lr_cosine_schedule(t, alpha_max, alpha_min, T_warmup, T_cosine):
    """
    Cosine annealing learning rate schedule with linear warmup.
    
    Args:
        t: Current iteration
        alpha_max: Maximum learning rate
        alpha_min: Minimum learning rate
        T_warmup: Number of warmup iterations
        T_cosine: Total iterations for cosine annealing
    
    Returns:
        Learning rate for iteration t
    """
    if t < T_warmup:
        # Linear warmup: lr increases linearly from 0 to alpha_max
        return alpha_max * t / T_warmup
    elif t <= T_cosine:
        # Cosine annealing
        progress = (t - T_warmup) / (T_cosine - T_warmup)
        return alpha_min + 0.5 * (alpha_max - alpha_min) * (1 + math.cos(math.pi * progress))
    else:
        # Post-annealing: constant at alpha_min
        return alpha_min


def save_checkpoint(
    model: nn.Module,
    optimizer: torch.optim.Optimizer,
    iteration: int,
    out: Union[str, Path]
) -> None:
    """
    Save model and optimizer checkpoint.
    
    Args:
        model: PyTorch model
        optimizer: PyTorch optimizer
        iteration: Current training iteration
        out: Output path or file handle
    """
    checkpoint = {
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'iteration': iteration,
    }
    torch.save(checkpoint, out)


def load_checkpoint(
    src: Union[str, Path],
    model: nn.Module,
    optimizer: torch.optim.Optimizer
) -> int:
    """
    Load model and optimizer checkpoint.
    
    Args:
        src: Checkpoint path or file handle
        model: PyTorch model to load state into
        optimizer: PyTorch optimizer to load state into
    
    Returns:
        iteration: Training iteration from checkpoint
    """
    checkpoint = torch.load(src, map_location='cpu')
    model.load_state_dict(checkpoint['model_state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    return checkpoint['iteration']
