"""
Byte-level BPE tokenizer implementation
"""
import json
import regex as re
from collections import Counter, defaultdict
from multiprocessing import Pool, cpu_count
import os


# GPT-2 style pre-tokenization regex
PAT = r"""'(?:[sdmt]|ll|ve|re)| ?\p{L}+| ?\p{N}+| ?[^\s\p{L}\p{N}]+|\s+(?!\S)|\s+"""


def get_chunk_boundaries(text, special_tokens):
    """
    Get text chunk boundaries, ensuring splits at special tokens

    This function can directly use the starter code provided in the assignment
    """
    if not special_tokens:
        # If no special tokens, entire text is one chunk
        return [0, len(text)]

    # Build regex pattern to find all special token positions
    pattern = "|".join(re.escape(token) for token in special_tokens)
    boundaries = [0]

    for match in re.finditer(pattern, text):
        # Split before each special token
        if match.start() > boundaries[-1]:
            boundaries.append(match.start())
        # Split after each special token
        boundaries.append(match.end())

    if boundaries[-1] < len(text):
        boundaries.append(len(text))

    return sorted(set(boundaries))


def pretokenize_chunk(args):
    """
    Pre-tokenize a single text chunk (for parallel processing)

    Args:
        args: (chunk_text, pattern) tuple

    Returns:
        Counter object, key is byte tuple, value is frequency
    """
    chunk_text, pattern = args
    word_freqs = Counter()

    # Use finditer instead of findall to save memory
    for match in re.finditer(pattern, chunk_text):
        pre_token = match.group()
        # Convert to byte sequence tuple
        byte_tuple = tuple(bytes([b]) for b in pre_token.encode('utf-8'))
        word_freqs[byte_tuple] += 1

    return word_freqs


def train_bpe(input_path, vocab_size, special_tokens=None):
    """
    Train byte-level BPE tokenizer

    Args:
        input_path: Training text file path
        vocab_size: Final vocabulary size (including special tokens)
        special_tokens: List of special tokens, e.g. ['<|endoftext|>']

    Returns:
        vocab: dict[int, bytes] - mapping from token_id to token_bytes
        merges: list[tuple[bytes, bytes]] - list of BPE merge operations
    """
    if special_tokens is None:
        special_tokens = []

    # 1. Initialize vocabulary with 256 byte values
    vocab = {i: bytes([i]) for i in range(256)}
    next_id = 256

    # 2. Add special tokens to vocabulary
    for special_token in special_tokens:
        special_bytes = special_token.encode('utf-8')
        vocab[next_id] = special_bytes
        next_id += 1

    # 3. Read training text
    with open(input_path, 'r', encoding='utf-8') as f:
        text = f.read()

    # 4. Get chunk boundaries (split at special tokens)
    boundaries = get_chunk_boundaries(text, special_tokens)

    # 5. Prepare chunks (excluding special tokens)
    chunks = []
    for i in range(len(boundaries) - 1):
        start, end = boundaries[i], boundaries[i + 1]
        chunk = text[start:end]

        # Check if this chunk is a special token
        is_special = False
        for special_token in special_tokens:
            if chunk == special_token:
                is_special = True
                break

        # Only process non-special-token chunks
        if not is_special and chunk.strip():
            chunks.append(chunk)

    # 6. Parallel pre-tokenization
    print(f"预分词 {len(chunks)} 个文本块...")
    num_processes = min(cpu_count(), len(chunks))

    if num_processes > 1:
        with Pool(num_processes) as pool:
            chunk_args = [(chunk, PAT) for chunk in chunks]
            results = pool.map(pretokenize_chunk, chunk_args)

        # Merge all results
        word_freqs = Counter()
        for result in results:
            word_freqs.update(result)
    else:
        # Single process handling
        word_freqs = Counter()
        for chunk in chunks:
            result = pretokenize_chunk((chunk, PAT))
            word_freqs.update(result)

    print(f"找到 {len(word_freqs)} 个唯一的预token")
    
    # 7. Iteratively perform BPE merges (optimized with incremental updates)
    merges = []
    num_merges = vocab_size - next_id

    # Initialize: count all adjacent byte pair frequencies (only once)
    pair_freqs = Counter()
    for word, freq in word_freqs.items():
        for i in range(len(word) - 1):
            pair = (word[i], word[i + 1])
            pair_freqs[pair] += freq

    for _ in range(num_merges):
        if not pair_freqs:
            break

        # Select the most frequent byte pair (break ties by lexicographic order)
        best_pair = max(pair_freqs.items(), key=lambda x: (x[1], x[0]))[0]

        # Record this merge
        merges.append(best_pair)

        # Create new token
        merged_token = best_pair[0] + best_pair[1]
        vocab[next_id] = merged_token
        next_id += 1

        # Incremental update: only update affected byte pair frequencies
        pairs_to_update = Counter()
        new_word_freqs = {}

        for word, freq in word_freqs.items():
            # Check if this word contains best_pair
            has_pair = False
            for i in range(len(word) - 1):
                if word[i] == best_pair[0] and word[i + 1] == best_pair[1]:
                    has_pair = True
                    break

            if not has_pair:
                # This word is unaffected, keep as is
                new_word_freqs[word] = freq
            else:
                # This word contains best_pair, needs merging
                # First subtract old byte pair frequencies
                for i in range(len(word) - 1):
                    pair = (word[i], word[i + 1])
                    pairs_to_update[pair] -= freq

                # Perform merge
                new_word = []
                i = 0
                while i < len(word):
                    if (i < len(word) - 1 and
                        word[i] == best_pair[0] and
                        word[i + 1] == best_pair[1]):
                        new_word.append(merged_token)
                        i += 2
                    else:
                        new_word.append(word[i])
                        i += 1

                new_word_tuple = tuple(new_word)
                new_word_freqs[new_word_tuple] = new_word_freqs.get(new_word_tuple, 0) + freq

                # Add new byte pair frequencies
                for i in range(len(new_word_tuple) - 1):
                    pair = (new_word_tuple[i], new_word_tuple[i + 1])
                    pairs_to_update[pair] += freq

        # Apply incremental updates to pair_freqs
        for pair, delta in pairs_to_update.items():
            pair_freqs[pair] += delta
            if pair_freqs[pair] <= 0:
                del pair_freqs[pair]

        word_freqs = new_word_freqs

    return vocab, merges


class Tokenizer:
    """BPE tokenizer class"""

    def __init__(self, vocab, merges, special_tokens=None):
        """Initialize tokenizer"""
        self.vocab = vocab
        self.merges = merges
        self.special_tokens = special_tokens if special_tokens else []

        # Create reverse vocabulary
        self.vocab_reversed = {v: k for k, v in vocab.items()}

        # Create fast lookup for special tokens
        self.special_token_bytes = {}
        for special_token in self.special_tokens:
            special_bytes = special_token.encode('utf-8')
            if special_bytes in self.vocab_reversed:
                self.special_token_bytes[special_token] = self.vocab_reversed[special_bytes]

    def encode(self, text):
        """Encode text to token IDs"""
        if not text:
            return []

        token_ids = []

        # Handle special tokens
        if self.special_tokens:
            # Build regex pattern
            special_pattern = "|".join(re.escape(token) for token in self.special_tokens)
            parts = re.split(f'({special_pattern})', text)

            for part in parts:
                if not part:
                    continue

                # Check if it's a special token
                if part in self.special_token_bytes:
                    token_ids.append(self.special_token_bytes[part])
                else:
                    # Regular text, perform BPE encoding
                    token_ids.extend(self._encode_chunk(part))
        else:
            token_ids = self._encode_chunk(text)

        return token_ids

    def _encode_chunk(self, text):
        """Encode regular text chunk (without special tokens)"""
        token_ids = []

        # Pre-tokenization
        for match in re.finditer(PAT, text):
            pre_token = match.group()

            # Convert to byte sequence
            word = [bytes([b]) for b in pre_token.encode('utf-8')]

            # Apply all merges in order
            for merge_pair in self.merges:
                word = self._apply_merge(word, merge_pair)

            # Convert to token IDs
            for token_bytes in word:
                if token_bytes in self.vocab_reversed:
                    token_ids.append(self.vocab_reversed[token_bytes])

        return token_ids

    def _apply_merge(self, word, merge_pair):
        """Apply one merge operation to word"""
        if len(word) < 2:
            return word

        merged_token = merge_pair[0] + merge_pair[1]
        new_word = []
        i = 0

        while i < len(word):
            if (i < len(word) - 1 and
                word[i] == merge_pair[0] and
                word[i + 1] == merge_pair[1]):
                new_word.append(merged_token)
                i += 2
            else:
                new_word.append(word[i])
                i += 1

        return new_word

    def decode(self, ids):
        """Decode token IDs to text"""
        byte_parts = []
        for token_id in ids:
            if token_id in self.vocab:
                byte_parts.append(self.vocab[token_id])

        all_bytes = b''.join(byte_parts)
        return all_bytes.decode('utf-8', errors='replace')

    def encode_iterable(self, iterable):
        """
        Lazy encoding for large file streams

        Args:
            iterable: Iterable of strings (e.g., file handle)

        Yields:
            int: token IDs
        """
        buffer = ""

        for chunk in iterable:
            if isinstance(chunk, bytes):
                chunk = chunk.decode('utf-8', errors='replace')

            buffer += chunk

            # When buffer is large enough, process a portion
            # Keep the last pre-token to prevent truncation
            if len(buffer) > 10000:  # Adjustable buffer size
                # Find a safe split point (last complete pre-token)
                matches = list(re.finditer(PAT, buffer))
                if len(matches) > 1:
                    # Keep the last match, process the rest
                    split_pos = matches[-1].start()
                    to_encode = buffer[:split_pos]
                    buffer = buffer[split_pos:]

                    for token_id in self.encode(to_encode):
                        yield token_id

        # Process remaining buffer
        if buffer:
            for token_id in self.encode(buffer):
                yield token_id

    @classmethod
    def from_files(cls, vocab_filepath, merges_filepath, special_tokens=None):
        """Load tokenizer from files"""
        # Load vocabulary
        with open(vocab_filepath, 'r', encoding='utf-8') as f:
            vocab_json = json.load(f)

        vocab = {}
        for key, value in vocab_json.items():
            token_id = int(key)
            if isinstance(value, str):
                # Assume value is hex string
                vocab[token_id] = bytes.fromhex(value)
            elif isinstance(value, list):
                # Assume value is byte list
                vocab[token_id] = bytes(value)
            else:
                vocab[token_id] = value.encode('utf-8')

        # Load merges
        with open(merges_filepath, 'r', encoding='utf-8') as f:
            merges_json = json.load(f)

        merges = []
        for merge_item in merges_json:
            if isinstance(merge_item, list) and len(merge_item) == 2:
                first = bytes.fromhex(merge_item[0]) if isinstance(merge_item[0], str) else bytes(merge_item[0])
                second = bytes.fromhex(merge_item[1]) if isinstance(merge_item[1], str) else bytes(merge_item[1])
                merges.append((first, second))

        return cls(vocab, merges, special_tokens)