"""Feedforward network for transformer."""

import torch
import torch.nn as nn


def silu(x):
    """
    SiLU/Swish activation function.
    
    SiLU(x) = x * σ(x) = x / (1 + e^(-x))
    
    Args:
        x: Input tensor
    
    Returns:
        Activated tensor
    """
    return x * torch.sigmoid(x)


class SwiGLU(nn.Module):
    """
    SwiGLU feedforward network.
    
    Implements: FFN(x) = W2(SiLU(W1x) ⊙ W3x)
    
    Reference: Shazeer (2020) "GLU Variants Improve Transformer"
    """

    def __init__(self, d_model, d_ff):
        """
        Initialize SwiGLU feedforward network.
        
        Args:
            d_model: Model dimension
            d_ff: Feedforward hidden dimension (typically 8/3 * d_model)
        """
        super().__init__()
        from student.layers import Linear
        
        self.w1 = Linear(d_model, d_ff)  # Gate projection
        self.w2 = Linear(d_ff, d_model)  # Down projection  
        self.w3 = Linear(d_model, d_ff)  # Up projection

    def forward(self, x):
        """
        SwiGLU forward pass.

        Args:
            x: Input tensor (..., d_model)

        Returns:
            Output tensor (..., d_model)
        """
        # FFN(x) = W2(SiLU(W1(x)) ⊙ W3(x))
        return self.w2(silu(self.w1(x)) * self.w3(x))