import torch
import numpy as np

def get_batch(dataset, batch_size, context_length, device):
    # 1. 随机选择 batch_size 个起始索引
    # 注意：最大索引不能超过 len(dataset) - context_length
    ix = torch.randint(len(dataset) - context_length, (batch_size,))
    
    # 2. 根据索引提取输入 x (context_length 长度)
    x = torch.stack([torch.from_numpy((dataset[i:i+context_length]).astype(np.int64)) for i in ix])
    
    # 3. 提取目标 y (相对于 x 向后偏移一位)
    y = torch.stack([torch.from_numpy((dataset[i+1:i+context_length+1]).astype(np.int64)) for i in ix])
    
    # 4. 将数据移动到指定设备 (CPU 或 CUDA)
    x, y = x.to(device), y.to(device)
    
    return x, y
