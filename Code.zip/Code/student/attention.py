"""Attention mechanisms for transformer."""

import torch
import torch.nn as nn
import math


def scaled_dot_product_attention(Q, K, V, mask=None):
    """
    Scaled dot-product attention: softmax(QK^T / sqrt(d_k)) V

    Args:
        Q: Query tensor (..., seq_len_q, d_k)
        K: Key tensor (..., seq_len_k, d_k)
        V: Value tensor (..., seq_len_v, d_v)
        mask: Optional boolean mask (..., seq_len_q, seq_len_k)
              True = CAN attend (information flows)
              False = CANNOT attend (will be masked to -inf)

    Returns:
        Attention output (..., seq_len_q, d_v)
    """
    d_k = Q.shape[-1]

    # Compute attention scores: QK^T / sqrt(d_k)
    scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(d_k)

    # Apply mask if provided
    # True = can attend (keep), False = cannot attend (mask to -inf)
    if mask is not None:
        scores = scores.masked_fill(~mask, float('-inf'))

    # Apply softmax
    from student.training import softmax
    attn_weights = softmax(scores, dim=-1)

    # Apply attention to values
    output = torch.matmul(attn_weights, V)

    return output


class RotaryPositionalEmbedding(nn.Module):
    """
    Rotary Position Embedding (RoPE).
    
    Precomputes cos and sin values for efficiency.
    """
    
    def __init__(self, d_k, theta, max_seq_len, device=None):
        """
        Args:
            d_k: Dimension of each attention head
            theta: Base for position encoding (typically 10000.0)
            max_seq_len: Maximum sequence length
            device: Device to store buffers
        """
        super().__init__()
        self.d_k = d_k
        self.theta = theta
        self.max_seq_len = max_seq_len
        
        # Precompute frequencies
        # theta_i = theta^(-2i/d_k) for i in [0, d_k/2)
        i = torch.arange(0, d_k // 2, device=device, dtype=torch.float32)
        freqs = theta ** (-2 * i / d_k)  # (d_k/2,)
        
        # Precompute position * frequency for all positions
        positions = torch.arange(max_seq_len, device=device, dtype=torch.float32)  # (max_seq_len,)
        angles = torch.outer(positions, freqs)  # (max_seq_len, d_k/2)
        
        # Precompute cos and sin
        # Register as buffer so they move with the model to different devices
        self.register_buffer('cos_cached', torch.cos(angles), persistent=False)
        self.register_buffer('sin_cached', torch.sin(angles), persistent=False)
    
    def forward(self, x, token_positions):
        """
        Apply RoPE to input tensor.
        
        Args:
            x: Input tensor (..., seq_len, d_k)
            token_positions: Position indices (..., seq_len)
                Can be any shape as long as last dim is seq_len
        
        Returns:
            Tensor with RoPE applied (..., seq_len, d_k)
        """
        # Get cos and sin for the requested positions
        # token_positions shape: (..., seq_len)
        cos_m = self.cos_cached[token_positions]  # (..., seq_len, d_k/2)
        sin_m = self.sin_cached[token_positions]  # (..., seq_len, d_k/2)
        
        # Split input into even and odd indices
        x_even = x[..., 0::2]  # (..., seq_len, d_k/2)
        x_odd = x[..., 1::2]   # (..., seq_len, d_k/2)
        
        # Apply rotation
        # [cos -sin] [x_even]   [x_even * cos - x_odd * sin]
        # [sin  cos] [x_odd ] = [x_even * sin + x_odd * cos]
        x_even_rot = x_even * cos_m - x_odd * sin_m
        x_odd_rot = x_even * sin_m + x_odd * cos_m
        
        # Interleave back
        output = torch.empty_like(x)
        output[..., 0::2] = x_even_rot
        output[..., 1::2] = x_odd_rot
        
        return output


class MultiHeadAttention(nn.Module):
    """Multi-head self-attention with optional RoPE."""

    def __init__(self, d_model, num_heads, use_rope=False, max_seq_len=None, theta=10000.0):
        """
        Args:
            d_model: Model dimension
            num_heads: Number of attention heads
            use_rope: Whether to use Rotary Position Embeddings
            max_seq_len: Maximum sequence length (required if use_rope=True)
            theta: RoPE theta parameter
        """
        super().__init__()
        assert d_model % num_heads == 0, "d_model must be divisible by num_heads"
        
        self.d_model = d_model
        self.num_heads = num_heads
        self.d_head = d_model // num_heads
        self.use_rope = use_rope
        
        from student.layers import Linear
        
        # Q, K, V projections
        self.q_proj = Linear(d_model, d_model)
        self.k_proj = Linear(d_model, d_model)
        self.v_proj = Linear(d_model, d_model)
        self.output_proj = Linear(d_model, d_model)
        
        # RoPE
        if use_rope:
            assert max_seq_len is not None, "max_seq_len required when use_rope=True"
            self.rope = RotaryPositionalEmbedding(self.d_head, theta, max_seq_len)

    def forward(self, x, token_positions=None):
        """
        Multi-head self-attention forward pass.
        
        Args:
            x: Input tensor (batch, seq_len, d_model)
            token_positions: Position indices (batch, seq_len)
                If None and use_rope=True, will use [0, 1, 2, ..., seq_len-1]

        Returns:
            Output tensor (batch, seq_len, d_model)
        """
        batch_size, seq_len, d_model = x.shape

        # Project to Q, K, V
        Q = self.q_proj(x)  # (batch, seq_len, d_model)
        K = self.k_proj(x)
        V = self.v_proj(x)

        # Reshape to (batch, num_heads, seq_len, d_head)
        Q = Q.view(batch_size, seq_len, self.num_heads, self.d_head).transpose(1, 2)
        K = K.view(batch_size, seq_len, self.num_heads, self.d_head).transpose(1, 2)
        V = V.view(batch_size, seq_len, self.num_heads, self.d_head).transpose(1, 2)

        # Apply RoPE if enabled
        if self.use_rope:
            if token_positions is None:
                # Create default positions [0, 1, 2, ..., seq_len-1]
                token_positions = torch.arange(seq_len, device=x.device).unsqueeze(0)
                # Expand to batch size
                token_positions = token_positions.expand(batch_size, -1)
            
            # Apply RoPE to Q and K (not V)
            Q = self.rope(Q, token_positions)
            K = self.rope(K, token_positions)

        # Create causal mask (prevent attending to future positions)
        # True = can attend, False = cannot attend
        # Lower triangular (including diagonal) = True
        causal_mask = torch.tril(
            torch.ones(seq_len, seq_len, device=x.device, dtype=torch.bool)
        )

        # Apply attention
        # attn_output shape: (batch, num_heads, seq_len, d_head)
        attn_output = scaled_dot_product_attention(Q, K, V, mask=causal_mask)

        # Reshape back to (batch, seq_len, d_model)
        attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = attn_output.view(batch_size, seq_len, d_model)

        # Apply output projection
        output = self.output_proj(attn_output)

        return output