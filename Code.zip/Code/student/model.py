"""Transformer model architecture."""

import torch
import torch.nn as nn


class TransformerBlock(nn.Module):
    """Pre-norm transformer block with attention and feedforward."""

    def __init__(self, d_model, num_heads, d_ff, max_seq_len, theta=10000.0):
        super().__init__()
        from student.layers import RMSNorm
        from student.attention import MultiHeadAttention
        from student.feedforward import SwiGLU

        self.ln1 = RMSNorm(d_model)
        self.attn = MultiHeadAttention(d_model, num_heads, use_rope=True,
                                       max_seq_len=max_seq_len, theta=theta)
        self.ln2 = RMSNorm(d_model)
        self.ffn = SwiGLU(d_model, d_ff)

    def forward(self, x, token_positions=None):
        """
        Pre-norm transformer block forward pass.

        Args:
            x: Input tensor (batch, seq_len, d_model)
            token_positions: Position indices (batch, seq_len)

        Returns:
            Output tensor (batch, seq_len, d_model)
        """
        # Pre-norm attention with residual
        x = x + self.attn(self.ln1(x), token_positions)
        # Pre-norm feedforward with residual
        x = x + self.ffn(self.ln2(x))
        return x


class TransformerLM(nn.Module):
    """Transformer language model."""

    def __init__(self, vocab_size, context_length, d_model, num_layers,
                 num_heads, d_ff, rope_theta=10000.0):
        super().__init__()
        from student.layers import Embedding, RMSNorm, Linear

        self.context_length = context_length
        self.token_embeddings = Embedding(vocab_size, d_model)
        self.layers = nn.ModuleList([
            TransformerBlock(d_model, num_heads, d_ff, context_length, rope_theta)
            for _ in range(num_layers)
        ])
        self.ln_final = RMSNorm(d_model)
        self.lm_head = Linear(d_model, vocab_size)

    def forward(self, input_ids):
        """
        Forward pass through transformer LM.

        Args:
            input_ids: Token IDs (batch, seq_len)

        Returns:
            Logits (batch, seq_len, vocab_size)
        """
        batch_size, seq_len = input_ids.shape

        # Create token positions
        token_positions = torch.arange(seq_len, device=input_ids.device).unsqueeze(0)
        token_positions = token_positions.expand(batch_size, -1)

        # Embed tokens
        x = self.token_embeddings(input_ids)

        # Apply transformer blocks
        for layer in self.layers:
            x = layer(x, token_positions)

        # Final norm and projection
        x = self.ln_final(x)
        logits = self.lm_head(x)

        return logits
